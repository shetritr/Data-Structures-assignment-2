
//Don't change the class name
public class Container{
	private Point data;//Don't delete or change this field;
	
	//Don't delete or change this function
	public Point getData()
	{
		return data;
	}
}
